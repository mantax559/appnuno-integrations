<?php echo $header; ?><?php echo $column_left; ?>
<div id="content">
  <link href="view/javascript/appnuno/settings.css?v=72de66f5d62e?v=<?php echo $appnuno_settings_css_version; ?>" rel="stylesheet" />
  <link href="view/javascript/appnuno/adapter.css?v=72de66f5d62e" rel="stylesheet" />
  <div class="page-header appnuno-host-header">
    <div class="container-fluid">
      <h1><?php echo $heading_title; ?></h1>
      <ul class="breadcrumb">
        <?php foreach ($breadcrumbs as $breadcrumb) { ?>
        <li><a href="<?php echo $breadcrumb['href']; ?>"><?php echo $breadcrumb['text']; ?></a></li>
        <?php } ?>
      </ul>
    </div>
  </div>
  <div class="container-fluid appnuno-page">
    <?php if ($success) { ?>
    <div class="alert alert-success"><i class="fa fa-check-circle"></i> <?php echo htmlspecialchars($success, ENT_QUOTES, 'UTF-8'); ?>
      <button type="button" class="close" data-dismiss="alert">&times;</button>
    </div>
    <?php } ?>
    <?php if ($error_warning) { ?>
    <div class="alert alert-danger"><i class="fa fa-exclamation-circle"></i> <?php echo $error_warning; ?>
      <button type="button" class="close" data-dismiss="alert">&times;</button>
    </div>
    <?php } ?>
    <?php if ($error_config) { ?>
    <div class="alert alert-danger"><i class="fa fa-exclamation-circle"></i> <?php echo htmlspecialchars($error_config, ENT_QUOTES, 'UTF-8'); ?>
      <button type="button" class="close" data-dismiss="alert">&times;</button>
    </div>
    <?php } ?>
    <div class="panel panel-default appnuno-settings">
      <div class="panel-heading appnuno-toolbar">
        <div class="appnuno-watermark" aria-hidden="true"></div>
        <div class="appnuno-brand">
          <img class="appnuno-brand-mark" src="https://appnuno.com/logo-dark.png" alt="AppNuno">
          <div class="appnuno-version-group">
            <span class="appnuno-version">v<?php echo htmlspecialchars($appnuno_version, ENT_QUOTES, 'UTF-8'); ?></span>
            <a class="appnuno-documentation" href="https://appnuno.com/opencart" target="_blank" rel="noopener noreferrer"><?php echo htmlspecialchars($text_documentation, ENT_QUOTES, 'UTF-8'); ?></a>
          </div>
        </div>
        <div class="appnuno-toolbar-actions appnuno-button-group">
          <a href="<?php echo $cancel; ?>" class="btn btn-default"><?php echo $button_cancel; ?></a>
          <button type="submit" form="form-appnuno" class="btn btn-primary"><?php echo $button_save; ?></button>
        </div>
      </div>
      <div class="panel-body">
        <form action="<?php echo $action; ?>" method="post" enctype="multipart/form-data" id="form-appnuno" class="form-horizontal">
          <input type="hidden" name="module_appnuno_config" id="input-config-json" value="" />
          <div class="appnuno-section-toolbar">
            <div class="appnuno-switch appnuno-section-switch">
              <span class="appnuno-switch-indicator" aria-hidden="true"></span>
              <ul class="nav nav-tabs">
                <li class="active"><a href="#tab-navigation" data-toggle="tab"><?php echo $text_default_tabs; ?></a></li>
                <li><a href="#tab-glass" data-toggle="tab"><?php echo $text['text_glass']; ?></a></li>
                <li><a href="#tab-colors" data-toggle="tab"><?php echo $text['text_navigation_colors']; ?></a></li>
              </ul>
            </div>
            <div class="form-group appnuno-status-field">
              <label class="col-sm-2 control-label" id="input-status-label" for="input-status"><?php echo $entry_status; ?></label>
              <div class="col-sm-10">
                <div class="appnuno-switch" data-status-switch="input-status">
                  <span class="appnuno-switch-indicator" aria-hidden="true"></span>
                  <?php if ($module_appnuno_status) { ?>
                  <button type="button" data-value="1" aria-pressed="true"><?php echo $text_enabled; ?></button>
                  <button type="button" data-value="0" aria-pressed="false"><?php echo $text_disabled; ?></button>
                  <?php } else { ?>
                  <button type="button" data-value="1" aria-pressed="false"><?php echo $text_enabled; ?></button>
                  <button type="button" data-value="0" aria-pressed="true"><?php echo $text_disabled; ?></button>
                  <?php } ?>
                </div>
                <?php if ($module_appnuno_status) { ?>
                <input type="hidden" name="module_appnuno_status" id="input-status" value="1" />
                <?php } else { ?>
                <input type="hidden" name="module_appnuno_status" id="input-status" value="0" />
                <?php } ?>
              </div>
            </div>
          </div>
          <div class="tab-content">
            <div class="tab-pane active" id="tab-navigation">
              <div id="default-tabs"></div>
            </div>
            <div class="tab-pane" id="tab-glass">
              <section class="appnuno-setting-card">
              <h2 class="appnuno-setting-title"><?php echo $text['text_back_button']; ?></h2>
              <div class="appnuno-setting-card-body">
              <div class="form-group">
                <label class="col-sm-2 control-label" for="back-enabled"><?php echo $text['entry_back_enabled']; ?></label>
                <div class="col-sm-10">
                  <select id="back-enabled" class="form-control">
                    <option value="1"><?php echo $text['text_yes']; ?></option>
                    <option value="0"><?php echo $text['text_no']; ?></option>
                  </select>
                </div>
              </div>
              <div class="form-group" data-show-when="back-enabled">
                <label class="col-sm-2 control-label" for="back-placement"><?php echo $text['entry_back_placement']; ?></label>
                <div class="col-sm-10">
                  <select id="back-placement" class="form-control">
                    <option value="separate"><?php echo $text['text_placement_separate']; ?></option>
                    <option value="bar"><?php echo $text['text_placement_bar']; ?></option>
                  </select>
                </div>
              </div>
              </div>
              </section>
              <section class="appnuno-setting-card">
              <h2 class="appnuno-setting-title"><?php echo $text['text_glass_button']; ?></h2>
              <div class="appnuno-setting-card-body">
              <div class="form-group">
                <label class="col-sm-2 control-label" for="glass-enabled"><?php echo $text['entry_glass_enabled']; ?></label>
                <div class="col-sm-10">
                  <select id="glass-enabled" class="form-control">
                    <option value="1"><?php echo $text['text_yes']; ?></option>
                    <option value="0"><?php echo $text['text_no']; ?></option>
                  </select>
                </div>
              </div>
              <div class="form-group" data-show-when="glass-enabled">
                <label class="col-sm-2 control-label" for="glass-color-scheme"><?php echo $text['entry_glass_color_scheme']; ?></label>
                <div class="col-sm-10">
                  <select id="glass-color-scheme" class="form-control">
                    <option value="auto"><?php echo $text['text_color_auto']; ?></option>
                    <option value="light"><?php echo $text['text_color_light']; ?></option>
                    <option value="dark"><?php echo $text['text_color_dark']; ?></option>
                  </select>
                </div>
              </div>
              <div class="form-group" data-show-when="glass-enabled">
                <label class="col-sm-2 control-label" for="glass-style"><?php echo $text['entry_glass_style']; ?></label>
                <div class="col-sm-10">
                  <select id="glass-style" class="form-control">
                    <option value="regular"><?php echo $text['text_style_regular']; ?></option>
                    <option value="clear"><?php echo $text['text_style_clear']; ?></option>
                    <option value="none"><?php echo $text['text_style_none']; ?></option>
                  </select>
                </div>
              </div>
              <div class="form-group" data-show-when="glass-enabled">
                <label class="col-sm-2 control-label" for="glass-animate"><?php echo $text['entry_glass_animate']; ?></label>
                <div class="col-sm-10">
                  <select id="glass-animate" class="form-control">
                    <option value="1"><?php echo $text_enabled; ?></option>
                    <option value="0"><?php echo $text_disabled; ?></option>
                  </select>
                </div>
              </div>
              <div class="form-group" data-show-when="glass-enabled">
                <label class="col-sm-2 control-label" for="glass-duration"><?php echo $text['entry_glass_duration']; ?></label>
                <div class="col-sm-10">
                  <input type="number" min="0" max="10" step="0.1" id="glass-duration" class="form-control appnuno-compact-control" placeholder="0.3" required="required" />
                </div>
              </div>
              <div class="form-group" data-show-when="glass-enabled">
                <label class="col-sm-2 control-label" for="glass-interactive"><?php echo $text['entry_glass_interactive']; ?></label>
                <div class="col-sm-10">
                  <select id="glass-interactive" class="form-control">
                    <option value="1"><?php echo $text_enabled; ?></option>
                    <option value="0"><?php echo $text_disabled; ?></option>
                  </select>
                </div>
              </div>
              <div class="form-group" data-show-when="glass-enabled">
                <label class="col-sm-2 control-label" for="glass-tint-color"><?php echo $text['entry_glass_tint']; ?></label>
                <div class="col-sm-10">
                  <input type="color" id="glass-tint-color" class="form-control" value="#000000" />
                </div>
              </div>
              <div class="form-group" data-show-when="glass-enabled">
                <label class="col-sm-2 control-label" for="glass-tint-alpha"><?php echo $text['entry_glass_opacity']; ?></label>
                <div class="col-sm-10">
                  <input type="number" min="0" max="1" step="0.01" id="glass-tint-alpha" class="form-control appnuno-compact-control" value="0.02" placeholder="0.02" required="required" />
                </div>
              </div>
              </div>
              </section>
            </div>
            <div class="tab-pane" id="tab-colors">
              <section class="appnuno-setting-card">
              <h2 class="appnuno-setting-title"><?php echo $text['text_light_mode']; ?></h2>
              <div class="appnuno-setting-card-body">
              <div class="form-group">
                <label class="col-sm-2 control-label" for="light-background"><?php echo $text['entry_background']; ?></label>
                <div class="col-sm-10">
                  <input type="color" id="light-background" class="form-control" value="#FFFFFF" />
                </div>
              </div>
              <div class="form-group">
                <label class="col-sm-2 control-label" for="light-content"><?php echo $text['entry_content']; ?></label>
                <div class="col-sm-10">
                  <input type="color" id="light-content" class="form-control" value="#2C3136" />
                </div>
              </div>
              </div>
              </section>
              <section class="appnuno-setting-card">
              <h2 class="appnuno-setting-title"><?php echo $text['text_dark_mode']; ?></h2>
              <div class="appnuno-setting-card-body">
              <div class="form-group">
                <label class="col-sm-2 control-label" for="dark-background"><?php echo $text['entry_background']; ?></label>
                <div class="col-sm-10">
                  <input type="color" id="dark-background" class="form-control" value="#2C3136" />
                </div>
              </div>
              <div class="form-group">
                <label class="col-sm-2 control-label" for="dark-content"><?php echo $text['entry_content']; ?></label>
                <div class="col-sm-10">
                  <input type="color" id="dark-content" class="form-control" value="#FFFFFF" />
                </div>
              </div>
              </div>
              </section>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<div class="modal" id="page-picker-dialog" tabindex="-1" role="dialog" aria-labelledby="page-picker-title">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="appnuno-modal-close" data-dismiss="modal" aria-label="<?php echo $button_cancel; ?>"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="page-picker-title"><?php echo $text['text_shown_on_pages']; ?></h4>
      </div>
      <div class="modal-body">
        <div id="page-picker-all-pages"></div>
        <div class="appnuno-page-picker-actions appnuno-button-group">
          <button type="button" class="btn btn-default" id="page-picker-select-all"><?php echo $text['button_select_all_pages']; ?></button>
          <button type="button" class="btn btn-default" id="page-picker-clear"><?php echo $text['button_clear_pages']; ?></button>
        </div>
        <div id="page-picker-choices" class="appnuno-page-picker-choices"></div>
      </div>
      <div class="modal-footer">
        <div class="appnuno-button-group">
          <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo $text['button_cancel_pages']; ?></button>
          <button type="button" class="btn btn-primary" id="page-picker-apply"><?php echo $text['button_apply_pages']; ?></button>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="modal" id="icon-picker-dialog" tabindex="-1" role="dialog" aria-labelledby="icon-picker-title">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="appnuno-modal-close" data-dismiss="modal" aria-label="<?php echo $button_cancel; ?>"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="icon-picker-title"><?php echo $text['text_icon']; ?></h4>
      </div>
      <div class="modal-body">
        <div class="appnuno-icon-toolbar">
          <input type="search" id="icon-picker-search" class="form-control" aria-label="<?php echo htmlspecialchars($icon_catalog_search, ENT_QUOTES, 'UTF-8'); ?>" maxlength="120" placeholder="<?php echo htmlspecialchars($icon_catalog_search, ENT_QUOTES, 'UTF-8'); ?>" />
        </div>
        <div class="appnuno-icon-meta">
          <p id="icon-picker-count"></p>
          <div class="appnuno-icon-pager appnuno-button-group" hidden></div>
        </div>
        <div class="appnuno-icon-stage">
          <div id="icon-picker-grid"></div>
          <div id="icon-picker-loading" class="appnuno-icon-loading" hidden>
            <span class="appnuno-spinner" aria-hidden="true"></span>
          </div>
        </div>
        <div id="icon-picker-status" role="status"></div>
        <div class="appnuno-icon-meta appnuno-icon-meta-bottom">
          <div class="appnuno-icon-pager appnuno-button-group" hidden></div>
        </div>
      </div>
    </div>
  </div>
</div>
<script type="application/json" id="appnuno-configuration"><?php echo $configuration_json; ?></script>
<script type="application/json" id="appnuno-text"><?php echo $text_json; ?></script>
<script type="application/json" id="appnuno-languages"><?php echo $languages_json; ?></script>
<script type="application/json" id="appnuno-destinations"><?php echo $destinations_json; ?></script>
<script type="application/json" id="appnuno-route-options"><?php echo $route_options_json; ?></script>
<script type="application/json" id="appnuno-validation-path"><?php echo $error_config_path_json; ?></script>
<script type="application/json" id="appnuno-default-language"><?php echo json_encode($default_language_code, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?></script>
<script src="view/javascript/appnuno/settings.js?v=72de66f5d62e"></script>
<?php echo $footer; ?>
