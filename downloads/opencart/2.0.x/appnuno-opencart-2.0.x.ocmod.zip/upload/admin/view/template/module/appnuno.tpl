<?php echo $header; ?><?php echo $column_left; ?>
<div id="content">
  <link href="view/javascript/appnuno/settings.css?v=392da5367bf3?v=<?php echo $appnuno_settings_css_version; ?>" rel="stylesheet" />
  <link href="view/javascript/appnuno/adapter.css?v=392da5367bf3" rel="stylesheet" />
  <div class="page-header appnuno-host-header">
    <div class="container-fluid">
      <h1><?php echo $heading_title; ?></h1>
      <ul class="breadcrumb">
        <?php foreach ($breadcrumbs as $breadcrumb) { ?>
        <li><a href="<?php echo $breadcrumb['href']; ?>"><?php echo $breadcrumb['text']; ?></a></li>
        <?php } ?>
      </ul>
    </div>
  </div>
  <div class="container-fluid appnuno-page">
    <?php if ($success) { ?>
    <div class="appnuno-alert appnuno-alert-success"><span class="appnuno-alert-icon" aria-hidden="true"><svg class="appnuno-icon" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="m5 12 5 5L20 7"/></svg></span> <?php echo htmlspecialchars($success, ENT_QUOTES, 'UTF-8'); ?>
      <button type="button" class="appnuno-alert-close" data-appnuno-dismiss="alert" aria-label="<?php echo $button_cancel; ?>">&times;</button>
    </div>
    <?php } ?>
    <?php if ($error_warning) { ?>
    <div class="appnuno-alert appnuno-alert-danger"><span class="appnuno-alert-icon" aria-hidden="true"><svg class="appnuno-icon" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 8v5M12 16h.01"/></svg></span> <?php echo $error_warning; ?>
      <button type="button" class="appnuno-alert-close" data-appnuno-dismiss="alert" aria-label="<?php echo $button_cancel; ?>">&times;</button>
    </div>
    <?php } ?>
    <?php if ($error_config) { ?>
    <div class="appnuno-alert appnuno-alert-danger"><span class="appnuno-alert-icon" aria-hidden="true"><svg class="appnuno-icon" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 8v5M12 16h.01"/></svg></span> <?php echo htmlspecialchars($error_config, ENT_QUOTES, 'UTF-8'); ?>
      <button type="button" class="appnuno-alert-close" data-appnuno-dismiss="alert" aria-label="<?php echo $button_cancel; ?>">&times;</button>
    </div>
    <?php } ?>
    <div class="appnuno-settings">
      <div class="appnuno-toolbar">
        <div class="appnuno-watermark" aria-hidden="true"></div>
        <div class="appnuno-brand">
          <img class="appnuno-brand-mark" src="https://appnuno.com/logo-dark.png" alt="AppNuno">
          <div class="appnuno-version-group">
            <span class="appnuno-version">v<?php echo htmlspecialchars($appnuno_version, ENT_QUOTES, 'UTF-8'); ?></span>
            <a class="appnuno-documentation" href="https://appnuno.com/opencart" target="_blank" rel="noopener noreferrer"><?php echo htmlspecialchars($text_documentation, ENT_QUOTES, 'UTF-8'); ?></a>
          </div>
        </div>
        <div class="appnuno-toolbar-actions appnuno-button-group">
          <a href="<?php echo $cancel; ?>" class="appnuno-button"><?php echo $button_cancel; ?></a>
          <button type="submit" form="form-appnuno" class="appnuno-button appnuno-button-primary"><?php echo $button_save; ?></button>
        </div>
      </div>
      <div class="appnuno-body">
        <form action="<?php echo $action; ?>" method="post" enctype="multipart/form-data" id="form-appnuno">
          <input type="hidden" name="module_appnuno_config" id="input-config-json" value="" />
          <div class="appnuno-section-toolbar">
            <div class="appnuno-switch appnuno-section-switch">
              <span class="appnuno-switch-indicator" aria-hidden="true"></span>
              <ul class="appnuno-section-list">
                <li class="active"><a href="#tab-navigation"><?php echo $text_default_tabs; ?></a></li>
                <li><a href="#tab-glass"><?php echo $text['text_glass']; ?></a></li>
                <li><a href="#tab-colors"><?php echo $text['text_navigation_colors']; ?></a></li>
              </ul>
            </div>
            <div class="appnuno-field appnuno-status-field">
              <label class="appnuno-field-label" id="input-status-label" for="input-status"><?php echo $entry_status; ?></label>
              <div class="appnuno-field-control">
                <div class="appnuno-switch" data-status-switch="input-status">
                  <span class="appnuno-switch-indicator" aria-hidden="true"></span>
                  <?php if ($module_appnuno_status) { ?>
                  <button type="button" data-value="1" aria-pressed="true"><?php echo $text_enabled; ?></button>
                  <button type="button" data-value="0" aria-pressed="false"><?php echo $text_disabled; ?></button>
                  <?php } else { ?>
                  <button type="button" data-value="1" aria-pressed="false"><?php echo $text_enabled; ?></button>
                  <button type="button" data-value="0" aria-pressed="true"><?php echo $text_disabled; ?></button>
                  <?php } ?>
                </div>
                <?php if ($module_appnuno_status) { ?>
                <input type="hidden" name="module_appnuno_status" id="input-status" value="1" />
                <?php } else { ?>
                <input type="hidden" name="module_appnuno_status" id="input-status" value="0" />
                <?php } ?>
              </div>
            </div>
          </div>
          <div class="appnuno-sections">
            <div class="appnuno-section appnuno-section-open" id="tab-navigation">
              <div id="default-tabs"></div>
            </div>
            <div class="appnuno-section" id="tab-glass">
              <section class="appnuno-setting-card">
              <h2 class="appnuno-setting-title"><?php echo $text['text_back_button']; ?></h2>
              <div class="appnuno-setting-card-body">
              <div class="appnuno-field">
                <label class="appnuno-field-label" for="back-enabled"><?php echo $text['entry_back_enabled']; ?></label>
                <div class="appnuno-field-control">
                  <select id="back-enabled" class="appnuno-input">
                    <option value="1"><?php echo $text['text_yes']; ?></option>
                    <option value="0"><?php echo $text['text_no']; ?></option>
                  </select>
                </div>
              </div>
              <div class="appnuno-field" data-show-when="back-enabled">
                <label class="appnuno-field-label" for="back-placement"><?php echo $text['entry_back_placement']; ?></label>
                <div class="appnuno-field-control">
                  <select id="back-placement" class="appnuno-input">
                    <option value="separate"><?php echo $text['text_placement_separate']; ?></option>
                    <option value="bar"><?php echo $text['text_placement_bar']; ?></option>
                  </select>
                </div>
              </div>
              </div>
              </section>
              <section class="appnuno-setting-card">
              <h2 class="appnuno-setting-title"><?php echo $text['text_glass_button']; ?></h2>
              <div class="appnuno-setting-card-body">
              <div class="appnuno-field">
                <label class="appnuno-field-label" for="glass-enabled"><?php echo $text['entry_glass_enabled']; ?></label>
                <div class="appnuno-field-control">
                  <select id="glass-enabled" class="appnuno-input">
                    <option value="1"><?php echo $text['text_yes']; ?></option>
                    <option value="0"><?php echo $text['text_no']; ?></option>
                  </select>
                </div>
              </div>
              <div class="appnuno-field" data-show-when="glass-enabled">
                <label class="appnuno-field-label" for="glass-color-scheme"><?php echo $text['entry_glass_color_scheme']; ?></label>
                <div class="appnuno-field-control">
                  <select id="glass-color-scheme" class="appnuno-input">
                    <option value="auto"><?php echo $text['text_color_auto']; ?></option>
                    <option value="light"><?php echo $text['text_color_light']; ?></option>
                    <option value="dark"><?php echo $text['text_color_dark']; ?></option>
                  </select>
                </div>
              </div>
              <div class="appnuno-field" data-show-when="glass-enabled">
                <label class="appnuno-field-label" for="glass-style"><?php echo $text['entry_glass_style']; ?></label>
                <div class="appnuno-field-control">
                  <select id="glass-style" class="appnuno-input">
                    <option value="regular"><?php echo $text['text_style_regular']; ?></option>
                    <option value="clear"><?php echo $text['text_style_clear']; ?></option>
                    <option value="none"><?php echo $text['text_style_none']; ?></option>
                  </select>
                </div>
              </div>
              <div class="appnuno-field" data-show-when="glass-enabled">
                <label class="appnuno-field-label" for="glass-animate"><?php echo $text['entry_glass_animate']; ?></label>
                <div class="appnuno-field-control">
                  <select id="glass-animate" class="appnuno-input">
                    <option value="1"><?php echo $text_enabled; ?></option>
                    <option value="0"><?php echo $text_disabled; ?></option>
                  </select>
                </div>
              </div>
              <div class="appnuno-field" data-show-when="glass-enabled">
                <label class="appnuno-field-label" for="glass-duration"><?php echo $text['entry_glass_duration']; ?></label>
                <div class="appnuno-field-control">
                  <input type="number" min="0" max="10" step="0.1" id="glass-duration" class="appnuno-input appnuno-compact-control" placeholder="0.3" required="required" />
                </div>
              </div>
              <div class="appnuno-field" data-show-when="glass-enabled">
                <label class="appnuno-field-label" for="glass-interactive"><?php echo $text['entry_glass_interactive']; ?></label>
                <div class="appnuno-field-control">
                  <select id="glass-interactive" class="appnuno-input">
                    <option value="1"><?php echo $text_enabled; ?></option>
                    <option value="0"><?php echo $text_disabled; ?></option>
                  </select>
                </div>
              </div>
              <div class="appnuno-field" data-show-when="glass-enabled">
                <label class="appnuno-field-label" for="glass-tint-color"><?php echo $text['entry_glass_tint']; ?></label>
                <div class="appnuno-field-control">
                  <input type="color" id="glass-tint-color" class="appnuno-input" value="#000000" />
                </div>
              </div>
              <div class="appnuno-field" data-show-when="glass-enabled">
                <label class="appnuno-field-label" for="glass-tint-alpha"><?php echo $text['entry_glass_opacity']; ?></label>
                <div class="appnuno-field-control">
                  <input type="number" min="0" max="1" step="0.01" id="glass-tint-alpha" class="appnuno-input appnuno-compact-control" value="0.02" placeholder="0.02" required="required" />
                </div>
              </div>
              </div>
              </section>
            </div>
            <div class="appnuno-section" id="tab-colors">
              <section class="appnuno-setting-card">
              <h2 class="appnuno-setting-title"><?php echo $text['text_light_mode']; ?></h2>
              <div class="appnuno-setting-card-body">
              <div class="appnuno-field">
                <label class="appnuno-field-label" for="light-background"><?php echo $text['entry_background']; ?></label>
                <div class="appnuno-field-control">
                  <input type="color" id="light-background" class="appnuno-input" value="#FFFFFF" />
                </div>
              </div>
              <div class="appnuno-field">
                <label class="appnuno-field-label" for="light-content"><?php echo $text['entry_content']; ?></label>
                <div class="appnuno-field-control">
                  <input type="color" id="light-content" class="appnuno-input" value="#2C3136" />
                </div>
              </div>
              </div>
              </section>
              <section class="appnuno-setting-card">
              <h2 class="appnuno-setting-title"><?php echo $text['text_dark_mode']; ?></h2>
              <div class="appnuno-setting-card-body">
              <div class="appnuno-field">
                <label class="appnuno-field-label" for="dark-background"><?php echo $text['entry_background']; ?></label>
                <div class="appnuno-field-control">
                  <input type="color" id="dark-background" class="appnuno-input" value="#2C3136" />
                </div>
              </div>
              <div class="appnuno-field">
                <label class="appnuno-field-label" for="dark-content"><?php echo $text['entry_content']; ?></label>
                <div class="appnuno-field-control">
                  <input type="color" id="dark-content" class="appnuno-input" value="#FFFFFF" />
                </div>
              </div>
              </div>
              </section>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<div class="appnuno-dialog" id="page-picker-dialog" hidden role="dialog" aria-modal="true" aria-labelledby="page-picker-title">
  <div class="appnuno-dialog-window" role="document">
    <div class="appnuno-dialog-panel">
      <div class="appnuno-dialog-header">
        <button type="button" class="appnuno-modal-close" data-appnuno-dismiss="dialog" aria-label="<?php echo $button_cancel; ?>"><span aria-hidden="true">&times;</span></button>
        <h4 class="appnuno-dialog-title" id="page-picker-title"><?php echo $text['text_shown_on_pages']; ?></h4>
      </div>
      <div class="appnuno-dialog-body">
        <div id="page-picker-all-pages"></div>
        <div class="appnuno-page-picker-actions appnuno-button-group">
          <button type="button" class="appnuno-button" id="page-picker-select-all"><?php echo $text['button_select_all_pages']; ?></button>
          <button type="button" class="appnuno-button" id="page-picker-clear"><?php echo $text['button_clear_pages']; ?></button>
        </div>
        <div id="page-picker-choices" class="appnuno-page-picker-choices"></div>
      </div>
      <div class="appnuno-dialog-footer">
        <div class="appnuno-button-group">
          <button type="button" class="appnuno-button" data-appnuno-dismiss="dialog"><?php echo $text['button_cancel_pages']; ?></button>
          <button type="button" class="appnuno-button appnuno-button-primary" id="page-picker-apply"><?php echo $text['button_apply_pages']; ?></button>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="appnuno-dialog" id="icon-picker-dialog" hidden role="dialog" aria-modal="true" aria-labelledby="icon-picker-title">
  <div class="appnuno-dialog-window" role="document">
    <div class="appnuno-dialog-panel">
      <div class="appnuno-dialog-header">
        <button type="button" class="appnuno-modal-close" data-appnuno-dismiss="dialog" aria-label="<?php echo $button_cancel; ?>"><span aria-hidden="true">&times;</span></button>
        <h4 class="appnuno-dialog-title" id="icon-picker-title"><?php echo $text['text_icon']; ?></h4>
      </div>
      <div class="appnuno-dialog-body">
        <div class="appnuno-icon-toolbar">
          <input type="search" id="icon-picker-search" class="appnuno-input" aria-label="<?php echo htmlspecialchars($icon_catalog_search, ENT_QUOTES, 'UTF-8'); ?>" maxlength="120" placeholder="<?php echo htmlspecialchars($icon_catalog_search, ENT_QUOTES, 'UTF-8'); ?>" />
        </div>
        <div class="appnuno-icon-meta">
          <p id="icon-picker-count"></p>
          <div class="appnuno-icon-pager appnuno-button-group" hidden></div>
        </div>
        <div class="appnuno-icon-stage">
          <div id="icon-picker-grid"></div>
          <div id="icon-picker-loading" class="appnuno-icon-loading" hidden>
            <span class="appnuno-spinner" aria-hidden="true"></span>
          </div>
        </div>
        <div id="icon-picker-status" role="status"></div>
        <div class="appnuno-icon-meta appnuno-icon-meta-bottom">
          <div class="appnuno-icon-pager appnuno-button-group" hidden></div>
        </div>
      </div>
    </div>
  </div>
</div>
<script type="application/json" id="appnuno-configuration"><?php echo $configuration_json; ?></script>
<script type="application/json" id="appnuno-text"><?php echo $text_json; ?></script>
<script type="application/json" id="appnuno-languages"><?php echo $languages_json; ?></script>
<script type="application/json" id="appnuno-destinations"><?php echo $destinations_json; ?></script>
<script type="application/json" id="appnuno-route-options"><?php echo $route_options_json; ?></script>
<script type="application/json" id="appnuno-validation-path"><?php echo $error_config_path_json; ?></script>
<script type="application/json" id="appnuno-default-language"><?php echo json_encode($default_language_code, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?></script>
<script src="view/javascript/appnuno/settings.js?v=392da5367bf3"></script>
<?php echo $footer; ?>
